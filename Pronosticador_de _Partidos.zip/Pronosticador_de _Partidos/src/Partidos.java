public class Partidos {
    private String Local;


}
